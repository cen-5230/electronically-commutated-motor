# 更新日志

本项目所有值得注意的变更都会记录在此文件中。


## [1.0] - 2026-10-06

### 新增

- **开环正反转功能**
  - 支持电机正转、反转、停止三种运行状态
  - 通过方向控制信号切换电机转向
  - 实现正反转切换时的状态管理

- **速度开环控制**
  - 基于给定值直接输出控制量，实现速度开环调节
  - 支持速度设定值的输入与更新
  - 无反馈环节，控制量随设定值线性变化

## [2.0] - 2026-10-07

### 优化

- **结构体变量命名规范**
  - 对全部结构体变量进行规范命名

- **结构体嵌套封装优化**
  - 优化结构体繁多的情况
  - 部分结构体合并，增加可读性，以及节省栈

## [3.0] - 2026-10-22

### 新增

- **位置闭环控制（重做）**
  - 位置环 PID 输出作为 q 轴电压给定，经斜坡限速和矢量限幅后送入 SVPWM
  - 位置误差使用 `FocMath_Wrap180()` 归一化，消除 0°/360° 边界处的误差跳变
  - FOC 计算与位置环统一到 TIM2 的 1 kHz 节拍执行

- **编码器两点式自动校准**
  - 依次施加电角度 0°、90° 的电压矢量，根据机械角变化方向自动判定编码器方向
  - 同时记录零偏，使电角度 0° 对应校准后的机械角 0°
  - 新增 `Encoder_SetDirection()`、`Encoder_SetOffsetDeg()`、`Encoder_ReadRawDeg()` 接口

- **FOC 输出保护**
  - 电压给定斜坡限速（默认 20 V/s），避免给定突变
  - dq 矢量幅值限幅，取最大相电压与线性调制区上限中的较小值
  - 增加扇区异常、矢量作用时间异常检测及母线电压异常的预留判据；故障时三相输出均分占空比
  - 预留 `FocCore_Start()` / `FocCore_Stop()` 与使能标志

- **参数集中配置**
  - 新增 `User/app/app_config.h`，集中电机参数（极对数、相电阻、最大相电流）、PWM 参数、母线电压、位置环 PID 参数和控制频率

- **通用算法模块**
  - 新增 `User/algorithm/math/math_angle.c`：角度归一化（2π/π/360°/180°）与限幅
  - 新增 `User/algorithm/control/switch.c`：函数查表分发框架（当前整体注释，仅作预留）

- **BSP 模块**
  - 新增 `User/bsp/bsp_pwm.c`：PWM 启停与三相比较值写入
  - 新增 `Get_Vbus()` 母线电压换算接口（暂未接入控制）

### 变更

- **工程结构重构**
  - 应用层独立为 `User/app`，`main.c` 只保留 HAL 初始化与 `App_Init()` / `App_Loop()` 调用
  - 底层驱动统一到 `User/bsp`，FOC 算法到 `User/foc`，通用算法到 `User/algorithm`
  - 删除空的 `User/control`、`User/motor` 目录

- **文件与接口重命名**
  - `foc.c/h` → `foc_core.c/h`，`closed_loop_foc()` → `Foc_InvPark_To_SVPWM()`
  - `PID.c/h` → `pid.c/h`，`VOFA.c/h` → `bsp_vofa.c/h`，`foc_filtering.c/h` → `filtering.c/h`
  - `svpwm_time_init()` → `FocSvpwm_Init()`，`Set_ccr()` → `Foc_CalcCcrFromVoltage()`
  - SVPWM 结构体字段由 `T1/T2/T0/Ts/vm` 改为 `t1_ticks/t2_ticks/t0_ticks/ts_ticks`

- **控制时序调整**
  - 2.0 中 FOC 计算位于 ADC 注入完成中断（20 kHz），位置环位于 TIM2（1 kHz）
  - 3.0 将 FOC 与位置环统一到 TIM2 的 1 kHz 中断，ADC 中断只负责更新原始采样值

- **编码器接口拆分**
  - `mt6701_iic_read()` 只负责读取原始角度，不再接收 FOC 结构体指针
  - 由 `Encoder_Update()` 统一完成方向、零偏、机械角与电角度换算
  - 电角度改用 `FocMath_Wrap2Pi()` 归一化，替代原来的 `fmodf()` 处理

- **PID 模块**
  - `PID_Init()` 只负责结构体清零，参数与限幅改由 `Pid_SetGains()` 设置
  - 微分先行/不完全微分的状态变量由全局变量改为函数内静态变量
  - `PID_Out_Update()`、`Integral_limiting()` 改为文件内静态函数

- **平均滤波**
  - `Average_filter()` 由可配置窗口（最大 32 点环形缓冲区）简化为固定 5 点滑动平均

- **ADC 模块**
  - 移除 ADC 中断中的 FOC 调用及母线电压滤波变量，回调只更新原始采样值

### 修复

- 修复位置环使用 0~360° 机械角时，过零处误差从约 -359° 跳变到 -1° 的问题
- 修复编码器方向未识别时位置环反馈方向可能相反的问题（增加方向自动校准）

### 移除

- 移除空模块 `clarke.c/h`
- 移除 2.0 中在 ADC 中断内调用位置环输出的逻辑（改由 TIM2 统一调度）
